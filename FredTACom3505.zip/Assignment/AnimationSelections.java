public enum AnimationSelections{
  Rock,
  Roll,
  Slide,
  SlideRockAndRoll,
  SlideAndRock,
  SlideAndRoll,
  RockAndRoll,
  None
}
